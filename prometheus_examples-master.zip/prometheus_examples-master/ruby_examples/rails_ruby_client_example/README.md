# README

This application corresponds to the ['Instrumenting a Ruby on Rails Application with Prometheus'](https://www.robustperception.io/instrumenting-a-ruby-on-rails-application-with-prometheus)  blogpost.

This example deploys a sample Golang application, Prometheus, and Grafana to Kubernetes.  

It ties in with a blogpost written about setting up Prometheus and Kubernetes on Azure.

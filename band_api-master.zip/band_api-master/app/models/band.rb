class Band < ApplicationRecord
  has_many :members
end

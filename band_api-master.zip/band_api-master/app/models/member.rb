class Member < ApplicationRecord
  belongs_to :band
end
